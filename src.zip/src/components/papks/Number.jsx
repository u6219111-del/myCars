import React from 'react'

function Number() {
  return (
    <div>
        
    </div>
  )
}

export default Number
import React from 'react'

function ContactUs() {
  return (
    <div>ContactUs</div>
  )
}

export default ContactUs